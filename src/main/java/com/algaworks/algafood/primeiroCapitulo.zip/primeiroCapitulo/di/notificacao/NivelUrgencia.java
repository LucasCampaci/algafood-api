package com.algaworks.algafood.di.notificacao;

public enum NivelUrgencia {
	URGENTE,
	SEM_URGENCIA
}
